window.addEventListener("load", function () {
  this.setTimeout(() => {
    this.location.href = "./PaymentGateway.html";
  }, 1000);
});
